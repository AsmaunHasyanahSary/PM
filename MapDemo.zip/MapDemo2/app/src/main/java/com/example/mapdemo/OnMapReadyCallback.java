package com.example.mapdemo;

public interface OnMapReadyCallback {
}
