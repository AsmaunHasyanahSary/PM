Contributing
============

Contributions are welcome. In order to contribute first fork the repository and create a pull
request. When submitting a PR the request will be automatically built and tested in a CI
environment, these tests must pass before any change is merged. One of the primary goals of this
library is compatibility with the Android SQLite API be sure to keep that in mind when proposing
any change.